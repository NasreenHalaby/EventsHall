
const myRepository = require('../DB/myRepository')
const express = require('express');
const router = express.Router();
const cors = require('cors');
const app = express();
const isDevelopment = true;
router.use(express.urlencoded({ extended: true }));
router.use(express.json());
if (isDevelopment) {
    router.use(cors({ origin: "http://localhost:3000", optionsSuccessStatus: 200 }));

}
function nothing() {

}

//for calendar
router.get("/addevent", isDevelopment ? cors() : nothing(), async (req, res) => {
    const x = await myRepository.findEventsByHall(req.query.hall, req.query.foodtype);
    console.log("******");
    console.log(req.query.hall);
    console.log(req.query.foodtype);
    console.log(x);
    res.send(x);
}
);

router.get("/findeventbyhall", isDevelopment ? cors() : nothing(), async (req, res) => {
    const x = await myRepository.findByHallAndDate(req.query.hall)
    console.log(req.query.hall);
    res.send(x);
}
);


//getalltasters
router.get("/justtry", isDevelopment ? cors() : nothing(), async (req, res) => {
    const x = await myRepository.FindMaxTasters(req.query.hall, req.query.date);
    res.send(x);
}
);

//adding taster to event
router.put("/addtaster/:hall/:date/:id", isDevelopment ? cors() : nothing(), async (req, res) => {
    const x = await myRepository.AddTaster(req.params.hall, req.params.date, req.params.id);
    console.log("/////");
    console.log(req.params);

    res.send(x);
}
);



// router.get("/maxtasters", isDevelopment ? cors() : nothing(), async (req, res) => {
//     const x = await myRepository.FindMaxTasters(req.query.hall, req.query.date);
//     res.send(x);
// console.log("******");
// console.log(req.query);
// console.log(x);
// if (x === true) {
//     res.send("can add reservation ");
// }
// else {
//     // console.log(result);
//     res.send("cant add res, we have 10 tasters")

// }

// }
// );
//add new event -manager
router.post("/events", isDevelopment ? cors() : nothing(), async (req, res) => {
    let isAllOK = await myRepository.addNewEvent(req.body)
    // console.log(req.body);
    // console.log("////");
    // console.log(isAllOK);
    if (isAllOK === true) {
        res.send("added a new event");
    }
    else {
        // console.log(result);
        res.send("unsuccessful adding new event")

    }
})


// Update info of a user by its id
router.put("/:phone", isDevelopment ? cors() : nothing(), async (req, res) => {
    let isAllOK = await myRepository.updateUserByPhone(req.params.phone, req.body);
    if (isAllOK === true) {
        res.send("successfully updated user");
    }
    else {
        res.send("unsuccessful to update ");
    }
});


// Get all users
router.get("/allreservatios", isDevelopment ? cors() : nothing(), async (req, res) => {
    const x = await myRepository.getAllUsers();
    res.send(x);
}
);

router.get("/check", isDevelopment ? cors() : nothing(), async (req, res) => {
    // console.log("///////");
    // console.log(req.query);
    const dates = req.query.date
    const halls = req.query.hall
    const x = await myRepository.checkIfExist(dates, halls);
    res.send(x);
}
);

//check phone and password
router.get("/login", isDevelopment ? cors() : nothing(), async (req, res) => {
    console.log("///////");
    console.log(req.query);
    const phone = req.query.phone
    const password = req.query.password
    const x = await myRepository.checkIfUserExist(phone, password);
    res.send(x);
}
);

// Delete a user by its id 
router.delete("/id", async (req, res) => {
    const x = await myRepository.deleteUserById(req.params.id);
    res.send(x);
});


//add user-post
router.post("/users", isDevelopment ? cors() : nothing(), async (req, res) => {
    let id = await myRepository.addNewUser(req.body)

    // .then((result) => {
    if (id) {
        res.send(id);
        myRepository.AddTaster(req.body.hall, req.body.date, id)
        myRepository.sendSms(req.query.phone)


    }
    else {

        res.send(null)

    }




    // console.log(isAllOK);
    // if (isAllOK === true) {
    //     res.send("added new user");
    // }
    // else {
    //     res.send("unsuccessful adding new user please choose another date or place ");
    // }
});




//Get all dates  
// router.get("/dates", isDevelopment ? cors() : nothing(), (req, res) => {

//     res.send(myRepository.AllDates());
// });



//delete person by name
// router.delete("/:Name", isDevelopment ? cors() : nothing(), (req, res) => {
//     let isAllOK = myRepository.deleteUserByName(req.params.Name);
//     console.log(req.params.Name);
//     if (isAllOK === true) {
//         res.send("deleted user");
//     }
//     else {
//         res.send("user with the provided name does not exist");
//     }
// });


//// Update info of a user by its phone number -put


module.exports = router;






