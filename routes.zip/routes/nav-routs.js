const RepositoryNav = require('../DB/navRepository')
const express = require('express');
const router = express.Router();
const cors = require('cors');
const app = express();
const isDevelopment = true;
router.use(express.urlencoded({ extended: true }));
router.use(express.json());
if (isDevelopment) {
    router.use(cors({ origin: "http://localhost:3000", optionsSuccessStatus: 200 }));

}
function nothing() {

}

//Get all nav
router.get("/nav", isDevelopment ? cors() : nothing(), (req, res) => {
    res.send(RepositoryNav.GetAllNav(req.body))
}
);

module.exports = router;