const mangerRepository = require('../DB/RepoManager')
const express = require('express');
const router = express.Router();
const cors = require('cors');
const app = express();
const isDevelopment = true;
router.use(express.urlencoded({ extended: true }));
router.use(express.json());
if (isDevelopment) {
    router.use(cors({ origin: "http://localhost:3000", optionsSuccessStatus: 200 }));

}
function nothing() {

}



router.get("/login", isDevelopment ? cors() : nothing(), async (req, res) => {
    console.log("///////");
    console.log(req.query);
    const name = req.query.name
    const password = req.query.password
    const x = await mangerRepository.checkIfManagerExist(name, password);
    res.send(x);
}
);

module.exports = router;