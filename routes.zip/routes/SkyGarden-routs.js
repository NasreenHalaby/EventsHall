const myRepository = require('../DB/SgImgRepo.js')
const express = require('express');
const router = express.Router();
const cors = require('cors');
const app = express();
const isDevelopment = true;
router.use(express.urlencoded({ extended: true }));
router.use(express.json());
if (isDevelopment) {
    router.use(cors({ origin: "http://localhost:3000", optionsSuccessStatus: 200 }));

}
function nothing() {

}
// router.use(express.static("public"));


router.get("/", isDevelopment ? cors() : nothing(), async (req, res) => {
    const x = await myRepository.getAllImages();
    res.send(x);
}
);
module.exports = router;