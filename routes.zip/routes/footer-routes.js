const RepositoryFooter = require('../DB/FtrRepository')
const express = require('express');
const router = express.Router();
const cors = require('cors');
const app = express();
const isDevelopment = true;
router.use(express.urlencoded({ extended: true }));
router.use(express.json());
if (isDevelopment) {
    router.use(cors({ origin: "http://localhost:3000", optionsSuccessStatus: 200 }));

}
function nothing() {

}

//Get all footer
router.get("/footer", isDevelopment ? cors() : nothing(), (req, res) => {
    res.send(RepositoryFooter.GetAllFooter(req.body))
}
);

module.exports = router;