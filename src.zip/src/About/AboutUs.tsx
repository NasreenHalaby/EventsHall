
import './AboutUs.css';
import { useEffect } from 'react';
import { abouttArr } from './Aboutitem';


export function AboutUs() {
    // useEffect(() => {
    //     (document.querySelector('.about') as HTMLElement).innerHTML = abouttArr.myinnerHTML
    // }, [])

    return (
        <div className='all-about'>
            <div className='photo'>

            </div >

            <div className='text-about'>
                <h4>WE OFFER HIGH QUALITY, BEAUTIFUL EVENT SPACES IN OUR VENUES</h4>
                <p>
                    Searching for wow-worthy party venues in Israel, can be time-consuming and tiring! <br /> At our venues, we offer a number of venue rental options to help you bring your dream event to life. <br /> Our experienced team knows what to look for and will help you plan your event, choose the right layout, and perfect the event down to the detail. <br /> Our venues is the perfect place to host weddings, private parties, birthdays, Mitzvahs and more.</p>


                {/* Location – The location a party venue in Israel, is everything. Our venue is close to churches, hotels, and is easily accessible for anyone living near or in the Los Angeles area. If you have out of town guests, our venue promotes easy access to your favorite places in the Los Angeles area. . */}

                <p> What It Includes – What should a party venues offer? <br /> At the venues, our catering and food services have a many types of food, allowing you and your guests to dine and get the true taste of what food is. <br /> We also offer services that include clean up, set up, event planning, lighting, sound, and a bridal suite for your pleasure.
                    <br /></p>

                <p>Setup – How conductive a venue space is for events matters, especially if you’re trying to find your dream party venue . <br /> Luckily, we have plenty of space to work with. Our venues can hold a total of 1300 guests. <br /> Perfect for intimate gatherings and receptions, our venues has plenty of space left over for guests to feel comfortable and dance the night away.

                </p>
            </div>
        </div>



    )
}
