import React from 'react';
import './Menu.css';
// import './css/lightbox.min.css';
// import './js/lightbox-plus-jquery.min.js'

import { ImSpoonKnife } from "react-icons/im";


export function Menu() {
    return (
        <div className='menu'>
            <div className='mpage'>
                <div className='menuSliders'>
                </div>
                <div className='imgpar'>
                    <div className='img'>
                    </div>
                    <div className='menu2'>
                        <h1>Our Kitchen <ImSpoonKnife /></h1>
                        <p>Our chef offers you a rich and varied gourmet menu,<br /> consisting of fine ingredients made locally. <br /> The menu includes classic dishes alongside original surprises with a creative touch - dishes of the kind that guests continue to talk about long after the event is over… <br /> You are welcome to schedule a tasting meeting and impress yourself.</p>
                        <a href="../reservation"> Come & Taste</a>

                    </div>
                </div>
                <br />
                <div className='between'></div>
                <br />
                <div className='images-menu'>
                    <a href="../images/m0.jpeg" > <img src="../images/m0small.jpeg" /></a>
                    <a href="../gallerymenu/m1.jpg"> <img src="../gallerymenu/m1small.jpg" /></a>
                    <a href="../gallerymenu/m2.jpg"> <img src="../gallerymenu/m2small.jpg" /></a>
                    <a href="../gallerymenu/m3.jpg"> <img src="../gallerymenu/m3small.jpg" /></a>
                    <a href="../gallerymenu/m4.jpg"> <img src="../gallerymenu/m4small.jpg" /></a>
                    <a href="../gallerymenu/m5.jpg"> <img src="../gallerymenu/m5small.jpg" /></a>
                    <a href="../gallerymenu/m6.jpg"> <img src="../gallerymenu/m6small.jpg" /></a>
                    <a href="../gallerymenu/m7.jpg"> <img src="../gallerymenu/m7small.jpg" /></a>
                    <a href="../gallerymenu/m8.jpg"> <img src="../gallerymenu/m8small.jpg" /></a>
                    <a href="../gallerymenu/m9.jpg"> <img src="../gallerymenu/m9small.jpg" /></a>
                    <a href="../gallerymenu/mm.jpg"> <img src="../gallerymenu/mmsmall.jpg" /></a>
                    <a href="../gallerymenu/mm1.jpg"> <img src="../gallerymenu/mm1small.jpg" /></a>
                    <a href="../gallerymenu/food6.jpg"> <img src="../gallerymenu/food6small.jpg" /></a>
                    <a href="../gallerymenu/food4.jpg"> <img src="../gallerymenu/food4small.jpg" /></a>
                    <a href="../gallerymenu/bostan2.jpg"> <img src="../gallerymenu/bostan2small.jpg" /></a>
                    <a href="../gallerymenu/m11.jpg"> <img src="../gallerymenu/m11small.jpg" /></a>



                </div>


            </div>
        </div>
    )
}

