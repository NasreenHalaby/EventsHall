export let bosItems = [
    {
        title: "venue",
        url: "/venue"
    },

    {
        title: "gallery",
        url: "/gallery"
    },

    {
        title: "map",
        url: "/map"
    },




]