import React from 'react'
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';
import '../SkyGarden/Skysliders.css'

export default function Slidersbos() {
    return (
        <div className='slide-img'>
            <Carousel className='sliders'>
                <div>
                    <img src="../elbostanimg/bosatn22.jpg" height="1000px" width="1200px" />



                </div>
                <div>
                    <img src="../elbostanimg/bostan.jpg" height="300px" width="200px" />

                </div>
                <div>
                    {/* <img src="../elbostanimg/skygarden.jpg" height="100px" width="200px" /> */}

                </div>
            </Carousel>
        </div>
    )
}
