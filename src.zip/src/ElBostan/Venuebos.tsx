import React from 'react'
import { GiBigDiamondRing, GiPartyPopper, GiWoodenChair, GiMusicalNotes } from 'react-icons/gi'
import { ImManWoman } from 'react-icons/im'
import { MdFoodBank } from 'react-icons/md'
import { BiDrink } from 'react-icons/bi'
import { FaSmoking, FaWheelchair } from 'react-icons/fa'
import { BsClock } from 'react-icons/bs'
import { VscDebugBreakpointLog } from 'react-icons/vsc'
import '../TajMahal/Venue.css'


export function Venuebos() {
    return (
        <div className='divaroundall'>
            <div className='title'>

                <h2 > EL-BOSTAN <GiBigDiamondRing /> </h2>
                <p>For an amazing opened air event,<br /> that includes an incredible garden design and a breathtaking sunset view of the glamorous Carmel mountain,<br />
                    El-Bostan will be your perfect choice.</p>


                <h2>CAPACITY</h2>
                <div className='capacity'>
                    <div className='seated'>
                        <dt>Seated <GiWoodenChair /></dt>
                        <dd>1000</dd>

                    </div>

                    <div className='standing'>
                        <dt>Standing <ImManWoman /></dt>
                        <dd>1000</dd>
                    </div>
                </div>
            </div>
            <br /><br />

            <br />
            <div className='line'></div>
            <div className='table'>
                <div className='dt'>
                    {/* <i className='icon-hat'></i> */}
                    <span>< GiPartyPopper className='icon' /> celebrations hosted here since </span>
                    <div className='date'>2010</div>

                </div>
                <div className='line'>

                </div>
            </div>
            <div>
                <div className='dt'>
                    {/* <i className='icon-hat'></i> */}
                    <span>< GiBigDiamondRing className='icon' /> venue spaces </span>
                    <div>indoor & outdoor venue spaces available</div>
                </div>
                <div className='line'>

                </div>
            </div>
            <div>
                <div className='dt'>
                    {/* <i className='icon-hat'></i> */}
                    <span><MdFoodBank className='icon' /> catering  </span>
                    <div>client can select the caterer of their choice</div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div>
                <div className='dt'>

                    <span><BiDrink className='icon' /> alcohol  </span>
                    <div>byo permitted – you can bring your own alcohol
                        licensed server is required</div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div>
                <div className='dt'>

                    <span><GiMusicalNotes className='icon' /> music  </span>
                    <div>indoors & outdoors</div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div>
                <div className='dt'>

                    <span><FaSmoking className='icon' /> smoking  </span>
                    <div>designated smoking areas only </div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div>
                <div className='dt'>

                    <span><FaWheelchair className='icon' /> handicap accessible  </span>
                    <div>yes </div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div>
                <div className='dt'>
                    <span><BsClock className='icon' /> opening days  </span>
                    <div> from sunday - saturday </div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div className='aminities'>
                <h2>AMENITIES</h2>
                <ul><li> <VscDebugBreakpointLog /> bridal suite/changing rooms onsite</li></ul>
                <ul><li> <VscDebugBreakpointLog />onsite restrooms</li></ul>
                <ul><li><VscDebugBreakpointLog /> ample parking onsite</li></ul>

            </div>
        </div>
    )
}
