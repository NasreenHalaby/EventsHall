
import { useEffect } from 'react';
import { Outlet, useNavigate } from 'react-router-dom'
import { tagItems } from '../TajMahal/TajItems'
import { bosItems } from './BosItems'
import './Elbostan.css'

export function Elbostan() {
    const Navigate = useNavigate();
    useEffect(() => {
        Navigate('/elbostan/venue')

    }, [])
    return (
        <div className='around-all'>
            <div className='bos'>
                <div className='sliderss'></div>
            </div>
            <div>

                <Navigat bosItems={bosItems} />
                <Outlet />
            </div>

        </div>
    )
}


export function Navigat(props: { bosItems: { title: string, url: string }[] }) {
    const Navigate = useNavigate()
    return (
        < div className='Categorie' >
            {props.bosItems.map((curr, i) => (
                <div className='Catego' key={i} onClick={() => { Navigate('/elbostan' + curr.url) }}>
                    {curr.title}
                </div>
            ))}

        </div >
    )
}