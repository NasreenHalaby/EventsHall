import React from 'react'

export function Gallerybos() {
    return (
        <div>Gallerybos</div>
    )
}
