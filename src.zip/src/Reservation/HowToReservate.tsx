import React from 'react'

export function HowToReservate() {
  return (
    <div><h1></h1></div>
  )
}
