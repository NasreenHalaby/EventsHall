import axios from 'axios';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { newUser } from '../App';
import { Calendarr } from './Calendarr';
// import './Reservation.css';
import './ConfirmReservation.css';



export function ConfirmReservation(props: { newUser: any }) {
    console.log(props.newUser);
    const click = { button: 4 };
    let [formInfo, setFormInfo] = useState({
        first: "",
        last: "",
        phone: "",
        email: "",
        hall: "",
        foodtype: "",
        // people: "",
        date: "",

    })

    let [someStr, setSomeStr] = useState("");


    function textWasChanged(

        e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLTextAreaElement> | React.ChangeEvent<HTMLSelectElement>,
        whichField: string) {
        // console.log("aaa" + dates);



        let newObj = {
            ...formInfo,
            ...{
                [whichField]: e.target.value
            }
        };
        setFormInfo(newObj);
    }

    function UpdateInfo(e: React.FormEvent<HTMLFormElement>) {
        // if (click.button === 1) {
        //     if (formInfo.first !== "") {
        //         newUser.first = formInfo.first;
        //     }
        //     if (formInfo.last !== "") {
        //         newUser.last = formInfo.last;
        //     }
        //     if (formInfo.phone !== "") {
        //         newUser.phone = formInfo.phone;
        //     }
        //     if (formInfo.email !== "") {
        //         newUser.email = formInfo.email;
        //     }
        //     if (formInfo.hall !== "") {
        //         newUser.hall = formInfo.hall;
        //     }
        //     if (formInfo.foodtype !== "") {
        //         newUser.foodtype = formInfo.foodtype;
        //     }
        //     if (formInfo.date !== "") {
        //         newUser.date = formInfo.date;
        //     }
        //     e.preventDefault();

        //     console.log(newUser);
        //     let url2 = "http://localhost:3221/users/"
        //     url2 = url2 + newUser.phone;

        //     console.log(url2);
        //     // console.log(formInfo);
        //     axios.put(url2, newUser)
        //         .then(response => {
        //             console.log(response.data);
        //             let msg = JSON.stringify(response.data);
        //             if (msg === '"successfully updated user"') {
        //                 alert(msg);
        //             }
        //         });
        // }

        // if (click.button === 2) {
        //     let url3 = "http://localhost:3221/users/"
        //     url3 = url3 + newUser.phone;
        //     axios.delete(url3)
        //         .then(response1 => {
        //             console.log(response1.data);
        //             let msg = JSON.stringify(response1.data);
        //             if (msg === '"deleted user"') {
        //                 alert(msg);
        //             }

        //         })
        // }

        if (click.button === 3) {
            let theNewUserId = ""
            const urll = "http://localhost:3221/users/users"
            axios.post(urll, newUser)
                .then(res => {
                    console.log(res);

                    theNewUserId = res.data
                    console.log(theNewUserId);

                    alert("added new user")


                })
            // const urll4 = "http://localhost:3221/users/addtaster/" + newUser.hall + "/" + newUser.date + "/" + theNewUserId
            // axios.put(urll4)
            //     .then(res => {
            //         console.log(res)
            //     })

            // try {

            //     let x = await
            //         fetch(urll,
            //             {
            //                 method: 'POST',
            //                 body: JSON.stringify(newUser)

            //             })
            //     console.log(newUser);
            //     let y = await x.json()
            //     console.log(y);
            // }
            // catch (err) {
            //     console.log(err);
            // }
            // .then(res => {
            //     return res.json()})
            //     .then(res => {
            //         console.log(res);
            //         console.log("hellofrompost");
            //     })


            // theNewUserId = res.data





        }
    }


    return (
        <div className='formPage3'>
            <div className='resform2'><h2>Confirm Your Reservation:</h2></div>
            <div className='form4' >
                <div className="center">
                    <form onSubmit={(e) => { UpdateInfo(e) }}>
                        <div className='name1' >
                            <label className="lbl" >Your Name:</label>

                            <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                setSomeStr(e.target.value);
                                textWasChanged(e, "first")
                            }}
                                type="text" id="fname" name="first" placeholder={props.newUser.first} />

                            <input onChange={(e) => { textWasChanged(e, "last") }}
                                type="text" id="lname" name="lname" placeholder={props.newUser.last} />
                        </div>

                        <div>
                            <label className="lbl">Phone Number:
                                <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    setSomeStr(e.target.value);
                                    textWasChanged(e, "phone")
                                }}
                                    type="number" id="phone" placeholder={props.newUser.phone} />
                            </label>
                        </div>

                        <div>
                            <label className="lbl">Email:
                                <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    setSomeStr(e.target.value);
                                    textWasChanged(e, "email")
                                }}
                                    type="text" id="email" placeholder={props.newUser.email} />
                            </label>
                        </div>


                        <div>
                            <label className="lbl"> Choose your event hall:
                                <select onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                                    setSomeStr(e.target.value);
                                    textWasChanged(e, "hall")
                                }}
                                    name="event hall " id="select1" defaultValue={props.newUser.hall} >
                                    <option value=" "> </option>
                                    <option value="Taj Mahal">Taj Mahal </option>
                                    <option value="Elbostan">EL-Bostan</option>
                                    <option value="Sky Garden">Sky Garden</option>
                                </select>

                            </label>
                        </div>



                        <div >
                            <label className="lbl"> Type Of Food:
                                <select onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                                    setSomeStr(e.target.value);
                                    textWasChanged(e, "foodtype")
                                }}

                                    name="food " id="select1" defaultValue={props.newUser.foodtype} >
                                    <option value=" "> </option>
                                    <option value="meat food">Meat Food </option>
                                    <option value="vegeterian food">Vegeterian Food</option>
                                    <option value="dairy food">Dairy Food</option>
                                    <option value="vegan food">Vegan Food</option>
                                    <option value="kosher food">Kosher Food</option>
                                    <option value="droze food">Droze Food</option>

                                </select>
                            </label>
                        </div>

                        <div>
                            <label className='lbl'>
                                Event date:
                            </label>
                            <input onChange={(e) => { textWasChanged(e, "date") }}
                                type="text" id="eventdate" name="event date"
                                defaultValue={props.newUser.date}
                            />
                        </div>

                        <div id="btn">
                            {/* <button type="submit" id="button3" onClick={() => (click.button = 1)}>update information</button>
                            <button type="submit" id="button4" onClick={() => (click.button = 2)}>delete reservation</button> */}
                            <button type="submit" id="button5" onClick={() => (click.button = 3)}> submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    )
}