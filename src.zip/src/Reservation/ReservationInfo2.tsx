import axios from 'axios';
import React, { useState } from 'react'
import { useNavigate } from 'react-router';
import { newUser } from '../App';
import './Reservation.css';


export function ReservationInfo2() {
    let [formInfo, setFormInfo] = useState({
        people: "",

    })

    // newUser.people = formInfo.people;

    let [someStr, setSomeStr] = useState("");


    function textWasChanged(

        e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLTextAreaElement> | React.ChangeEvent<HTMLSelectElement>,
        whichField: string) {
        // console.log("aaa" + dates);



        let newObj = {
            ...formInfo,
            ...{
                [whichField]: e.target.value
            }
        };
        setFormInfo(newObj);

    }
    // const Navigate = useNavigate()
    function formSubmit(e: React.FormEvent<HTMLFormElement>) {
        // Navigate('/AfterRes')
        console.log(formInfo);
    }

    return (
        <div>

            {/* <input type="submit" id="button" value={"Make Reservation"} onSubmit={(e) => { formSubmit(e) }} /> */}

        </div>
    )
}
