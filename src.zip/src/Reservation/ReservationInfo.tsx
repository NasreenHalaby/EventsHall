import axios from 'axios';
import React, { useState } from 'react'
import { newUser } from '../App';
import { Calendarr } from './Calendarr';


export function ReservationInfo() {
    let [formInfo, setFormInfo] = useState({
        hall: "",
        foodtype: ""

    })

    newUser.hall = formInfo.hall;
    newUser.foodtype = formInfo.foodtype;


    let [someStr, setSomeStr] = useState("");
    const PageDisplay = { Calendarr }

    function textWasChanged(

        e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLTextAreaElement> | React.ChangeEvent<HTMLSelectElement>,
        whichField: string) {
        // console.log("aaa" + dates);



        let newObj = {
            ...formInfo,
            ...{
                [whichField]: e.target.value
            }
        };
        setFormInfo(newObj);

    }

    // const url2 = "http://localhost:3221/users/check"
    // axios.get(url2, { params: { date: formInfo.date, hall: formInfo.hall } })
    //     .then(response => {
    //         // console.log(response.data);
    //         if (response.data === false) {
    //             alert("unsuccessful adding new user please choose another date or place")
    //         }
    //     });
    //         let result = response.data;
    //         if (result.date !== newUser.date && result.hall !== newUser.hall) {
    //             const url1 = "http://localhost:3221/users/users"
    //             // console.log(formInfo);
    //             axios.post(url1)
    //                 .then(res => {
    //                     console.log(res);
    //                 })
    // }
    // else {
    //     alert("unsuccessful adding new user please choose another date or place ")
    // }



    // });

    //         const url1 = "http://localhost:3221/users/users"



    //         console.log(formInfo);
    //         axios.post(url1, formInfo)
    //             .then(res => {
    //                 console.log(res);
    //                 let msg = JSON.stringify(res.data);
    //                 if (msg === '"unsuccessful adding new user please choose another date or place "') {
    //                     alert(msg);
    //                 }
    //             });
    return (
        <div>
            <div className='page2'>
                <br /><br /><br />
                <label className="lbl"> Choose your event hall:
                    <select onChange={(e) => { textWasChanged(e, "hall") }}
                        name="event hall " id="select" placeholder="event hall " >
                        <option value=" "> </option>
                        <option value="Taj Mahal">Taj Mahal </option>
                        <option value="Elbostan">EL-Bostan</option>
                        <option value="Sky Garden">Sky Garden</option>
                    </select>

                </label>
            </div>
            <br /><br /><br />
            <div >
                <label className="lbl"> Type Of Food:
                    <select onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                        setSomeStr(e.target.value);
                        textWasChanged(e, "foodtype")
                    }}

                        name="food " id="select" placeholder="food type " >
                        <option value=" "> </option>
                        <option value="meat food">Meat Food </option>
                        <option value="vegeterian food">Vegeterian Food</option>
                        <option value="dairy food">Dairy Food</option>
                        <option value="vegan food">Vegan Food</option>
                        <option value="kosher food">Kosher Food</option>
                        <option value="droze food">Droze Food</option>

                    </select>
                </label>
                <br />
                <br /><br /><br /><br /><br /> <br /><br />

            </div>
            {/* <div>
                            <Calendarr/>
                        </div> */}
            {/* <div>
                <label className="lbl"> What kind of event:
                    <select onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                        setSomeStr(e.target.value);
                        textWasChanged(e, "kindevent")
                    }}
                        name="kindevent " id="select" placeholder="kindevent "  >
                        <option value=" "> </option>
                        <option value="Party">Party</option>
                        <option value="Wedding">Wedding</option>
                        <option value="Engagement">Engagement</option>
                        <option value="Birthday">Birthday</option>
                        <option value="Birth Event">Birth Event</option>
                    </select>
                </label>
            </div> */}
            {/* <br /> <br /> */}

            {/* <div>
                <label className='lbl'>
                    Event date:
                </label>
                <input onChange={(e) => { textWasChanged(e, "date") }}
                    type="date" id="eventdate" name="event date"
                    min="2022-02-02" max={"2024-01-10"} />
            </div> */}
            {/* <br /> <br /> */}
            {/* <div className='page3'>
                <label className="lbl"> How many people:
                    <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                        setSomeStr(e.target.value);
                        textWasChanged(e, "people")
                    }}
                        type="number" id="numpeople" placeholder="How many people" />

                </label>
            </div> */}
        </div>
    )
}
