import './Reservation.css';
import { useState, useEffect } from "react";
import axios from 'axios';
import { newUser } from '../App';
import { Navigate, useNavigate } from 'react-router-dom';
import 'antd/dist/antd.css';
import { PersonalInfo } from './PersonalInfo';
import { ReservationInfo } from './ReservationInfo';
import { ReservationInfo2 } from './ReservationInfo2';
import { ConfirmReservation } from './ConfirmReservation';
// import { AfterRes } from '../AfterRes/AfterRes';
import { Calendarr } from './Calendarr';
import { MdFoodBank } from 'react-icons/md';



export function Reservation() {
    const [page, setPage] = useState(0);
    const [formInfo, setFormInfo] = useState({
        first: "",
        last: "",
        phone: "",
        email: "",
        hall: "",
        date: "",
        people: "",
    })


    const FormTitles = ["PersonalInfo", "ReservationInfo", "Calendarr"]

    const PageDisplay = () => {
        if (page === 0) {
            return <PersonalInfo />;
        }
        else if (page === 1) {
            return <ReservationInfo />
        }
        else {
            return <Calendarr />
        }
        // else {
        //     return <ConfirmReservation newUser={newUser} />

        // }


    }


    const Navigate = useNavigate()
    // function addUser() {
    //     const url1 = "http://localhost:3221/users/users"
    //     axios.post(url1, newUser)
    //         .then(res => {
    //             console.log(res.data);

    //             Navigate('../AfterRes')
    //         })


    // }
    // function nav()


    function formSubmit(e: React.FormEvent<HTMLFormElement>) {
        e.preventDefault();
    }

    return (
        <div className='aroundformm'>
            <div className='formPage'>
                <div className='resform'>
                    <h2>Come & Taste Our Food <MdFoodBank className='foodicon' /> </h2>
                </div>

                <div className='pr'>
                    <div style={{ width: page === 0 ? "25%" : page === 1 ? "50%" : page === 1 ? "75%" : "100%" }}></div>
                </div>

                <div className='form1' >
                    <div className='left'></div>
                    <div className='right'>

                        <div className='formContainer'>

                            <div className='body'>{PageDisplay()}</div>
                            <div className='footer'>
                                <button id='button1'
                                    disabled={page == 0}
                                    onClick={() => { setPage((currPage) => currPage - 1) }}>Prev</button>
                                <button id='button2'
                                    // disabled={page == FormTitles.length - 1}

                                    onClick={page !== FormTitles.length - 1 ? () => { setPage((currPage) => currPage + 1) } :
                                        () => { Navigate('./ConfirmReservation') }}>Next</button>


                            </div>
                        </div>
                    </div>

                </div>

            </div >
        </div>

    )

    // {page != FormTitles.length - 1 ? () => { setPage((currPage) => currPage + 1) } :
    // () => {addUser()}}>Next</button>




    // return (
    //     <div className='formPage'>
    //         <div className='form1' >

    // )
}
























{/* const Navigate = useNavigate()
    let [formInfo, setFormInfo] = useState({
        first: "",
        last: "",
        phone: "",
        hall: "",
        kindevent: "",
        date: "",
        people: "",

    })

    newUser.first = formInfo.first;
    newUser.last = formInfo.last;
    newUser.phone = formInfo.phone;
    newUser.hall = formInfo.hall;
    newUser.kindevent = formInfo.kindevent;
    newUser.date = formInfo.date
    newUser.people = formInfo.people



    // const url = "http://localhost:3221/users/dates"





    let [someStr, setSomeStr] = useState("");


    function textWasChanged(

        e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLTextAreaElement> | React.ChangeEvent<HTMLSelectElement>,
        whichField: string) {
        // console.log("aaa" + dates);



        let newObj = {
            ...formInfo,
            ...{
                [whichField]: e.target.value
            }
        };
        setFormInfo(newObj);
        // console.log(newObj.date);



    }

    function formSubmit(e: React.FormEvent<HTMLFormElement>) {
        e.preventDefault();
        console.log(formInfo);
        Navigate('/AfterRes')
        // checkIfDateExist(formInfo.date)
        const url2 = "http://localhost:3221/users"
        axios.get(url2)
            .then(response => {
                console.log(response.data);
                let dates = response.data;
                console.log(dates);


            });

        const url1 = "http://localhost:3221/users/users" */}


{/* 
console.log(formInfo);
        axios.post(url1, formInfo)
            .then(res => {
                console.log(res);
                let msg = JSON.stringify(res.data);
                if (msg === '"unsuccessful adding new user please choose another date or place "') {
                    alert(msg);
                }
            });
    } */}