import React, { useEffect, useState } from 'react'
import 'antd/dist/antd.css';
import { Calendar, Badge } from 'antd';
import './Calendarr.css'
import axios from 'axios';
import { newUser } from '../App';
import moment from 'moment';
import 'moment/locale/zh-cn';
import { CalendarMode } from 'antd/lib/calendar/generateCalendar';
import { CalendarProps } from 'antd-weekly-calendar/dist/components/types';
moment.locale('zh-cn');

export function Calendarr() {

    const [event, setEvent] = useState([{ id: "", date: "" }])
    useEffect(() => {
        const url = "http://localhost:3221/users/addevent"
        axios.get(url, { params: { hall: newUser.hall, foodtype: newUser.foodtype } })
            .then(response => {
                console.log(newUser.hall);
                console.log(newUser.foodtype);
                let eventss = response.data;
                console.log(eventss);

                setEvent(eventss);
            })



    }, []);



    function getListData(value: any) {
        // The default locale is en-US, if you wan to use other locale, just set locale in entry file globally.


        let dateValue = value.format("yyyy-MM-DD")

        let listData1 = { type: "error" };

        for (let i = 0; i < event.length; i++) {
            if (event[i].date === dateValue) {
                listData1 = { type: 'success' }
                return listData1;

            }




        }
        return listData1 || {};






    }

    function disabledDate(date: moment.Moment) {
        // Can not select days before today and today
        return date && date.valueOf() < Date.now();
    }

    function dateCellRender(value: any) {
        let listData = getListData(value);
        // console.log(listData.type);
        let aa: "error" | "success" | "processing" | "default" | "warning" | undefined = "success"


        switch (listData.type) {


            case ("success"):
                // console.log(aa)
                aa = "success";
                break;

            case ("error"):

                aa = "error";
                break;
        }
        if (aa === "error") {
            return (
                <ul className="events" >
                    {/* {listData.map(item => ( */}
                    <li>
                        <Badge status={aa} />
                    </li>
                    {/* text={listData.content} */}
                </ul>
            );
        }
        else {
            return (
                <ul className="events" >
                    {/* {listData.map(item => ( */}
                    <li>
                        <Badge status={aa} />
                    </li>

                </ul>
            );
        }
    }

    function getMonthData(value: { month: () => number; }) {
        if (value.month() === 8) {
            return 1394;
        }
    }

    function monthCellRender(value: any) {
        const num = getMonthData(value);
        return num ? (
            <div className="notes-month">
                <section>{num}</section>
                <span>Backlog number</span>
            </div>
        ) : null;
    }


    // function(date: moment）
    function onSelect(date: moment.Moment) {
        let dateValue1 = date.format("yyyy-MM-DD")
        console.log(dateValue1);
        newUser.date = dateValue1;
        // const url2 = "http://localhost:3221/users/justtry"


        // axios.get(url2, { params: { hall: newUser.hall, date: newUser.date } })
        // .then(res => {
        //     console.log(res);

        // })

    }





    return (
        <div className='calendar'>

            <Calendar dateCellRender={dateCellRender}
                monthCellRender={monthCellRender}
                onSelect={onSelect}

                disabledDate={disabledDate}


            />

        </div>
    )
}
