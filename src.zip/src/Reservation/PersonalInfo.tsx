import React, { useState } from 'react'
import { newUser } from '../App';
import './Reservation.css';

export function PersonalInfo() {

    let [formInfo, setFormInfo] = useState({
        first: "",
        last: "",
        phone: "",
        email: "",
        // password: ""
    })
    // const [formErrors , setFormErrors] = useState({})
    newUser.first = formInfo.first;
    newUser.last = formInfo.last;
    newUser.phone = formInfo.phone;
    newUser.email = formInfo.email


    let [someStr, setSomeStr] = useState("");


    function textWasChanged(

        e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLTextAreaElement> | React.ChangeEvent<HTMLSelectElement>,
        whichField: string) {

        let newObj = {
            ...formInfo,
            ...{
                [whichField]: e.target.value
            }
        };
        setFormInfo(newObj);

    }

    // const validate = (values) => {
    //     const errors = {};
    //     const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    //     if(!values.first){
    //         errors.first =  "name is required"
    //     }

    // }


    return (
        <div>
            <div className='name' >
                <label className="lbl" >Your Name:</label>

                <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setSomeStr(e.target.value);
                    textWasChanged(e, "first")
                }}
                    type="text" id="fname" name="first" placeholder="first" required />

                <input onChange={(e) => { textWasChanged(e, "last") }}
                    type="text" id="lname" name="lname" placeholder="last" required />
            </div>
            <br /><br />
            <div>
                <label className="lbl">Phone Number:
                    <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                        setSomeStr(e.target.value);
                        textWasChanged(e, "phone")
                    }}
                        type="number" id="phone" placeholder="phone" />
                </label>
            </div>
            <br /><br />
            <div>
                <label className="lbl">Email:
                    <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                        setSomeStr(e.target.value);
                        textWasChanged(e, "email")
                    }}
                        type="text" id="email" placeholder="email" />
                </label>
            </div>
            {/* <div>
                <label className="lbl">Password:
                    <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                        setSomeStr(e.target.value);
                        textWasChanged(e, "password")
                    }}
                        type="password" id="password" placeholder="•••••••" />
                </label>
            </div> */}
        </div>
    )
}
