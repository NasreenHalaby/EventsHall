
import './App.css';
import { Navbar } from './Navbar/Navbar';
import { navArr } from './Navbar/Nav_items';
import { Footer } from './Footer/Footer';
import { footerArr } from './Footer/Footer_items';
import { BrowserRouter, Routes, Route, Navigate, useRoutes } from 'react-router-dom';
import { Home } from './Home/Home';
import { Elbostan } from './ElBostan/Elbostan';
import { Tajmahal } from './TajMahal/Tajmahal';
import { Skygarden } from './SkyGarden/Skygarden';
import { Reservation } from './Reservation/Reservation';
import { ContactUs } from './ContactUs/ContactUs';
import { AboutUs } from './About/AboutUs';
import { Menu } from './menu/Menu';
import { Login } from './manager/Login';
import { ForManager } from './manager/ForManager';
import { Allreservations } from './manager/Allreservations';
import { Addevent } from './manager/Addevent';
import { Venue } from './TajMahal/Venue';
import { Gallery } from './TajMahal/Gallery';
import { Mapp } from './TajMahal/Mapp';
import { SkyVenue } from './SkyGarden/SkyVenue';
import { SkyGallery } from './SkyGarden/SkyGallery';
import { SkyMap } from './SkyGarden/SkyMap';
import { ConfirmReservation } from './Reservation/ConfirmReservation';
import { Venuebos } from './ElBostan/Venuebos';
import { Gallerybos } from './ElBostan/Gallerybos';
import { Mapbos } from './ElBostan/Mapbos';
import { Check } from './Home/Check';
import { Calendar2 } from './Home/Calendar2';
import { Howitwork } from './Footer/Howitwork';
export let newUser = { first: "", last: "", phone: "", email: "", hall: "", foodtype: "", date: "" }





function App() {
  return (
    <div className="App-header">
      <header>
        <Navbar />

      </header>

      <BrowserRouter>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/check" element={<Check />} />
          <Route path="/check/calendar2" element={<Calendar2 />} />


          <Route path="/tajmahal" element={< Tajmahal />}>
            <Route path='/tajmahal/venue' element={<Venue />} />
            <Route path='/tajmahal/gallery' element={<Gallery />} />
            <Route path='/tajmahal/map' element={<Mapp />} />


          </Route>



          <Route path="/elbostan" element={<Elbostan />} >
            <Route path='/elbostan/venue' element={< Venuebos />} />
            <Route path='/elbostan/gallery' element={< Gallerybos />} />
            <Route path='/elbostan/map' element={< Mapbos />} />
          </Route>



          <Route path="/skygarden" element={<Skygarden />} >
            <Route path='/skygarden/venue' element={<SkyVenue />} />
            <Route path='/skygarden/gallery' element={<SkyGallery />} />
            <Route path='/skygarden/map' element={<SkyMap />} />


          </Route>
          <Route path="/reservation" element={<Reservation />} />
          <Route path='/reservation/confirmreservation' element={<ConfirmReservation newUser={newUser} />} />



          <Route path="/menu" element={<Menu />} />
          <Route path="/contactUs" element={<ContactUs />} />
          <Route path="/aboutUs" element={<AboutUs />} />
          <Route path="/manager" element={<Login />} />
          <Route path="/manager/formanager" element={<ForManager />} />
          <Route path="/manager/formanager/allreservations" element={<Allreservations />} />
          <Route path="/manager/formanager/addevent" element={<Addevent />} />
          <Route path="/howitworks" element={<Howitwork />} />

        </Routes>
      </BrowserRouter>


      {/* <Home Homeitems={homeArr} /> */}

      <Footer />



    </div>
  );

}
export default App;
