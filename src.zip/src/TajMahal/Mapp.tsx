import React from 'react'
import { GoogleMap, useLoadScript, Marker } from "@react-google-maps/api";
import './Mapp.css'



export function Mapp() {
  const { isLoaded } = useLoadScript({
    googleMapsApiKey: "AIzaSyBqk9olkNWIaHCYxlLSflh77D1x20YFDz4"
  })

  if (!isLoaded) return <div> Loading...</div>
  return (
    <div className='mapp'><Map /></div>
  )
}



function Map() {
  return <GoogleMap
    zoom={10} center={{ lat: 32.68659603221093, lng: 35.03868554473511 }}
    mapContainerClassName="map-container">
    <Marker position={{ lat: 32.68659603221093, lng: 35.03868554473511 }} />
  </GoogleMap>


}