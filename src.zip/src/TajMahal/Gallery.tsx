import React, { useState } from 'react';
import { Image } from 'antd';
import './Gallery.css'

export function Gallery() {
    const [visible, setVisible] = useState(false);
    return (
        <div className='gallery'>
            <Image className='gimg'
                preview={{ visible: false }}
                width={700}
                src='../tajImages/taj mahal.jpg'
                onClick={() => setVisible(true)}
            />
            <div style={{ display: 'none' }}>
                <Image.PreviewGroup preview={{ visible, onVisibleChange: vis => setVisible(vis) }}>
                    <Image src='../tajImages/taj mahal.jpg' />
                    <Image src='../tajImages/tajm1.jpg' />
                    <Image src='../tajImages/tm4.jpg' />
                    <Image src='../tajImages/tm.jpg' />
                    <Image src='../tajImages/tm0.jpg' />
                    <Image src='../tajImages/tm1.jpg' />
                    <Image src='../tajImages/tajmahal.jpg' />
                    <Image src='../tajImages/tajm.jpg' />
                    <Image src='../tajImages/taj.jpg' />
                    <Image src='../tajImages/tajm4.jpg' />
                    <Image src='../tajImages/tm2.jpg' />
                    <Image src='../tajImages/tm3.jpg' />
                    <Image src='../tajImages/tm11.jpg' />
                    <Image src='../tajImages/tmm.jpg' />
                </Image.PreviewGroup>
            </div>
        </div>
    )
}


