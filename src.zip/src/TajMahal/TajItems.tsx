export let tagItems = [
    {
        title: "venue",
        url: "/venue"
    },

    {
        title: "gallery",
        url: "/gallery"
    },

    {
        title: "map",
        url: "/map"
    },




]