import React, { useEffect } from 'react'
import { Outlet, useNavigate } from 'react-router-dom'
import { Sliders } from './Sliders'
import './Tajmahal.css'
import { tagItems } from './TajItems'





export function Tajmahal() {
    const Navigate = useNavigate();
    useEffect(() => {
        Navigate('/tajmahal/venue')

    }, [])
    return (
        <div className='aroundall'>
            <div className='slidersAndwords'>
                <div className='slider'></div>
                {/* <div className='words'> <h1> Welcome To Taj-Mahal </h1></div> */}
            </div>
            <div>

                <Navigat tagItems={tagItems} />
                <Outlet />
            </div>
        </div>

    )
}

export function Navigat(props: { tagItems: { title: string, url: string }[] }) {
    const Navigate = useNavigate()
    return (
        < div className='Categorie' >
            {props.tagItems.map((curr, i) => (
                <div className='Catego' key={i} onClick={() => { Navigate('/tajmahal' + curr.url) }}>
                    {curr.title}
                </div>
            ))}

        </div >
    )
}





