import React from 'react'
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';
import './Sliders.css'

export function Sliders() {
    return (
        <div>
            <Carousel className='main-sliders'>
                <div>
                    <img src="../tajImages/tajm1.jpg" height="300px" width="200px" />


                </div>
                <div>
                    <img src="../tajImages/tm3.jpg" height="1000px" width="1200px" />

                </div>
                <div>
                    <img src="../tajImages/tajm4.jpg" height="100px" width="200px" />

                </div>
            </Carousel>

        </div>
    )
}
