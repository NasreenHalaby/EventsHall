import React from 'react'

export function Media() {
    return (
        <div>Media</div>
    )
}
