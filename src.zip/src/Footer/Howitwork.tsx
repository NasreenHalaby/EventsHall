import React from 'react'

export function Howitwork() {
    return (
        <div>
            <div>
                <h2>Welcome To Our Halls</h2>
            </div>

            <div></div>
        </div>




    )

}
