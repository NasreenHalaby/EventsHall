import axios from 'axios';
import { useState, useEffect } from 'react';
import './Footer.css';

//this function get an array that contains footerArr object,each object contain url+title and display it on the web page.
// export function Footer(props: { footeritems: { title: string, url: string }[] }) {
//     return (
//         <div className="Footer">
//             <ul className="footerItemsUl">
//                 {props.footeritems.map((curr, i) => (
//                     <li key={i}><a href={curr.url}> {curr.title}</a>  </li>
//                 ))}
//             </ul>


//         </div>
//     )
// }

export function Footer() {
    const url1 = "http://localhost:3221/footer/footer";
    const [Footer, setFooter] = useState([{ title: "", url: "" }]);
    useEffect(() => {
        axios.get(url1)
            .then(response => {
                console.log(response.data);
                setFooter(response.data);
            });
    }, []);

    return (
        <div className="Footer">
            <ul className="footerItemsUl">
                {Footer.map((curr, i) => {
                    return <Foot key={i} {...curr}></Foot>;
                })}
            </ul>


        </div>

    );
}

const Foot = (props: {
    title: string, url: string
}) => {
    return (

        <li><a href={props.url}> {props.title}</a> </li>


    )
}


