export let footerArr = [
    {
        title: "Contact Us",
        url: "contactUs"
    },
    {
        title: "Help Center",
        url: "help Center"
    },
    {
        title: "About Us",
        url: "aboutUs"
    },
    {
        title: "Media Center",
        url: "media Center"
    },
    {
        title: "How It Works",
        url: "how It Works"
    },

    {
        title: "Personal Reservation",
        url: "afterres"
    }
];


