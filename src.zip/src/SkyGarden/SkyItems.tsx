export let skyItems = [
    {
        title: "venue",
        url: "/venue"
    },

    {
        title: "gallery",
        url: "/gallery"
    },

    {
        title: "map",
        url: "/map"
    },




]