import React from 'react'
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';
import './Skysliders.css'


export function Skysliders() {
    return (
        <div className='slide-img'>
            <Carousel className='sliders'>
                <div>
                    <img src="../images/sg.jpg" height="300px" width="200px" />


                </div>
                <div>
                    <img src="../images/sg2.jpg" height="1000px" width="1200px" />

                </div>
                <div>
                    <img src="../images/skygarden.jpg" height="100px" width="200px" />

                </div>
            </Carousel>
        </div>
    )
}
