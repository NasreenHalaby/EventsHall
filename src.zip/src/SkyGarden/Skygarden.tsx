import React from 'react'
import './Skygarden.css';
import axios from 'axios'
import { useEffect, useState } from 'react';
import { Skysliders } from './Skysliders';
import { useNavigate, Outlet } from 'react-router-dom';
import { skyItems } from './SkyItems';

export function Skygarden() {
    const Navigate = useNavigate();
    useEffect(() => {
        Navigate('/skygarden/venue')

    }, [])


    return (
        <div className="sgAroundAll">
            <div className="sgImges">
                <Skysliders />
            </div>

            <div>

                <Navigat skyItems={skyItems} />
                <Outlet />
            </div>

        </div>

    );
}
const Img = (props: {
    img: string
}) => {
    return (
        <li> <img src={props.img} /></li>
    )
}





export function Navigat(props: { skyItems: { title: string, url: string }[] }) {
    const Navigate = useNavigate()
    return (
        < div className='Categorie' >
            {props.skyItems.map((curr, i) => (
                <div className='Catego' key={i} onClick={() => { Navigate('/skygarden' + curr.url) }}>
                    {curr.title}
                </div>
            ))}

        </div >
    )
}