import React from 'react'
import { GiBigDiamondRing, GiPartyPopper, GiWoodenChair, GiMusicalNotes } from 'react-icons/gi'
import { ImManWoman } from 'react-icons/im'
import { MdFoodBank } from 'react-icons/md'
import { BiDrink } from 'react-icons/bi'
import { FaSmoking, FaWheelchair } from 'react-icons/fa'
import { BsClock } from 'react-icons/bs'
import { VscDebugBreakpointLog } from 'react-icons/vsc'

import '../TajMahal/Venue.css'

export function SkyVenue() {
    return (
        <div className='divaroundall'>

            <div className='title'>

                <h2 >SKY GARDEN <GiBigDiamondRing /> </h2>
                <p>Sky Garden, which overlooks pastoral hills, doesn’t only feature a beautiful garden, and an impressive central space. But It also has it’s unique way in combining harmoniously natural elements, with it’s warm and natural  design. <br />

                    This is a modular complex that allows you to produce customized events and fulfill your dreams at the most important moment in your life. Sky Garden is also suitable for corporate events and marketing business conferences, the "company showcase", which require careful planning, appropriate equipment and maximum design flexibility. </p>


                <h2>CAPACITY</h2>
                <div className='capacity'>
                    <div className='seated'>
                        <dt>Seated <GiWoodenChair /></dt>
                        <dd>1000</dd>

                    </div>

                    <div className='standing'>
                        <dt>Standing <ImManWoman /></dt>
                        <dd>1000</dd>
                    </div>
                </div>
            </div>
            <br /><br />

            <br />
            <div className='line'></div>
            <div className='table'>
                <div className='dt'>
                    {/* <i className='icon-hat'></i> */}
                    <span>< GiPartyPopper className='icon' /> celebrations hosted here since </span>
                    <div className='date'>2020</div>

                </div>
                <div className='line'>

                </div>
            </div>
            <div>
                <div className='dt'>
                    {/* <i className='icon-hat'></i> */}
                    <span>< GiBigDiamondRing className='icon' /> venue spaces </span>
                    <div>indoor & outdoor venue spaces available</div>
                </div>
                <div className='line'>

                </div>
            </div>
            <div>
                <div className='dt'>
                    {/* <i className='icon-hat'></i> */}
                    <span><MdFoodBank className='icon' /> catering  </span>
                    <div>client can select the caterer of their choice</div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div>
                <div className='dt'>

                    <span><BiDrink className='icon' /> alcohol  </span>
                    <div>There is a bar with a variety of alcohol</div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div>
                <div className='dt'>

                    <span><GiMusicalNotes className='icon' /> music  </span>
                    <div>indoors & outdoors</div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div>
                <div className='dt'>

                    <span><FaSmoking className='icon' /> smoking  </span>
                    <div>designated smoking areas only </div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div>
                <div className='dt'>

                    <span><FaWheelchair className='icon' /> handicap accessible  </span>
                    <div>yes </div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div>
                <div className='dt'>
                    <span><BsClock className='icon' /> opening days  </span>
                    <div> from sunday - thursday </div>
                </div>
                <div className='line'>

                </div>
            </div>

            <div className='aminities'>
                <h2>AMENITIES</h2>
                <ul><li> <VscDebugBreakpointLog /> bridal suite/changing rooms onsite</li></ul>
                <ul><li> <VscDebugBreakpointLog />onsite restrooms</li></ul>
                <ul><li><VscDebugBreakpointLog /> ample parking onsite</li></ul>

            </div>
        </div>

    )
}
