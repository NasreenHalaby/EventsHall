import React, { useState } from 'react';
import { Image } from 'antd';

export function SkyGallery() {
    const [visible, setVisible] = useState(false);

    return (
        <div className='gallery'>
            <Image className='gimg'
                preview={{ visible: false }}
                width={700}
                src='../Images/sg4.jpeg'
                onClick={() => setVisible(true)}
            />

            <div style={{ display: 'none' }}>
                <Image.PreviewGroup preview={{ visible, onVisibleChange: vis => setVisible(vis) }}>
                    <Image src='../Images/sg4.jpeg' />
                    <Image src='../Images/skyg2.jpg' />
                    <Image src='../Images/skyg1.jpg' />
                    <Image src='../Images/skyim.jpeg' />
                    <Image src='../Images/skyyyg.jpg' />
                    <Image src='../Images/skyg.jpg' />
                    <Image src='../Images/sg9.jpg' />
                    <Image src='../Images/sg3.jpg' />
                    <Image src='../Images/sg2.jpg' />
                    <Image src='../Images/sg0.jpeg' />
                    <Image src='../Images/sg.jpg' />
                    <Image src='../Images/skygarden.jpg' />
                    <Image src='../Images/skygar.jpeg' />
                    <Image src='../Images/simg.jpeg' />
                </Image.PreviewGroup>
            </div>



        </div>
    )
}

