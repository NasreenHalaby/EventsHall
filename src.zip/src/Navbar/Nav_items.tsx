export let navArr = [
    {
        title: "HOME",
        url: "/home"
    },
    {
        title: "TAJ MAHAL",
        url: "/taj mahal"
    },
    {
        title: "EL-BOSTAN",
        url: "/el-bostan"
    },
    {
        title: "SKY GARDEN",
        url: "/sky garden"
    },

    {
        title: "RESERVATION",
        url: "/reservation"
    }
];