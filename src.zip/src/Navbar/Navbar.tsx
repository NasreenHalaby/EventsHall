import './Navbar.css';
import axios from 'axios'
import { useEffect, useState } from 'react';


//this function get an array that contains navArr object,each object contain url+title and display it on the web page.
// export function Navbar(props: { navItems: { title: string, url: string }[], logoImageUrl: string }) {
//     return (
//         <div className="Navbar">
//             <div className="mainItems">
//                 <div> <img className="logoImg" src={props.logoImageUrl} /> </div>
//                 <ul className="pagesItemsUl">
//                     {props.navItems.map((curr, i) => (
//                         <li key={i}><a href={curr.url}> {curr.title}</a> </li>
//                     ))}

//                 </ul>
//             </div>

//         </div>
//     )
// }




export function Navbar() {
    const url = "http://localhost:3221/nav/nav";
    const [Nav, setNav] = useState([{ title: "", url: "" }]);
    useEffect(() => {
        axios.get(url)
            .then(response => {
                console.log(response.data);
                setNav(response.data);
            });
    }, []);

    return (
        <div className="Navbar">
            <div className="mainItems">
                <div> <img className="logoImg" src={'./Mylogo.png'} />
                </div>




                <ul className="pagesItemsUl">
                    {Nav.map((curr, i) => {
                        return <Navb key={i} {...curr}></Navb>;
                    })}
                </ul>
            </div>

        </div>

    );
}

const Navb = (props: {
    title: string, url: string
}) => {
    return (

        <li><a href={props.url}> {props.title}</a> </li>


    )
}






