import axios from 'axios';
import React, { useState } from 'react'
import { Navigate } from 'react-router-dom';
import { newUser } from '../App';
import { Calendarr } from '../Reservation/Calendarr';
import './Addevent.css';


export function Addevent() {
    const [eventsInfo, setEventsInfo] = useState({
        hall: "",
        date: "",
        hour: "",
        foodtype: "",
        peoplenumber: ""

    })

    let [someStr, setSomeStr] = useState("");
    function textWasChanged(

        e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLTextAreaElement> | React.ChangeEvent<HTMLSelectElement>,
        whichField: string) {
        // console.log("aaa" + dates);



        let newObj = {
            ...eventsInfo,
            ...{
                [whichField]: e.target.value
            }
        };
        setEventsInfo(newObj);

    }

    function formWasSubmitted(e: React.FormEvent<HTMLFormElement>) {
        e.preventDefault();
        console.log(eventsInfo);
        const url1 = "http://localhost:3221/users/events"
        axios.post(url1, setEventsInfo)
            .then(res => {
                console.log(res.data);

                // Navigate('../AfterRes')
            })

    }
    return (
        <div className='aroundform'>
            <div><h2> Add Events</h2></div>

            <div className='addevent'>
                <div className='formm'>
                    <form onSubmit={(e) => { formWasSubmitted(e) }}>
                        <div className='hall' >
                            <label className="lbl"> Event Hall:
                                <select onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                                    setSomeStr(e.target.value);
                                    textWasChanged(e, "hall")
                                }}

                                    name="hall " id="select" placeholder="event hall " >
                                    <option value=" "> </option>
                                    <option value="Taj Mahal">Taj Mahal </option>
                                    <option value="Elbostan">EL-Bostan</option>
                                    <option value="Sky Garden">Sky Garden</option>
                                </select>
                            </label>
                        </div>
                        <div className='date'>
                            <label className='lbl'>
                                Event date:
                            </label>
                            <input onChange={(e) => { textWasChanged(e, "date") }}
                                type="date" id="eventdate" name="date"
                                min="2022-02-02" max={"2024-01-10"} />
                        </div>
                        <div className='hour'>
                            <label className="lbl">Event Hour:
                                <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    setSomeStr(e.target.value);
                                    textWasChanged(e, "hour")
                                }}
                                    type="text" id="eventhour" placeholder="hour" />
                            </label>
                        </div>

                        <div className='food'>
                            <label className="lbl"> Type Of Food:
                                <select onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                                    setSomeStr(e.target.value);
                                    textWasChanged(e, "foodtype")
                                }}

                                    name="food " id="select" placeholder="food type " >
                                    <option value=" "> </option>
                                    <option value="meat food">Meat Food </option>
                                    <option value="vegeterian food">Vegeterian Food</option>
                                    <option value="dairy food">Dairy Food</option>
                                    <option value="vegan food">Vegan Food</option>
                                    <option value="kosher food">Kosher Food</option>
                                    <option value="droze food">Droze Food</option>
                                </select>
                            </label>
                        </div>

                        <div className='people'>
                            <label className="lbl"> People Number:
                                <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    setSomeStr(e.target.value);
                                    textWasChanged(e, "peoplenumber")
                                }}
                                    type="text" id="peoplenumber" placeholder="peoplenumber" />
                            </label>
                        </div>
                        <div className='submit'>
                            <input type="submit" value="Add Event" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}
