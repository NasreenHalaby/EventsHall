import axios from 'axios';
import React, { useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom';
import './LogIn.css'
// import { AfterRes } from '../AfterRes/AfterRes';
import { newUser } from '../App';


export function Login() {
    const Navigate = useNavigate()
    const [formInfo, setFormInfo] = useState({
        name: "",
        password: "",

    })

    let [someStr, setSomeStr] = useState("");





    function textWasChanged(
        e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLTextAreaElement>,
        whichField: string) {

        let newObj = {
            ...formInfo,
            ...{
                [whichField]: e.target.value
            }
        };

        setFormInfo(newObj);
        // console.log(formInfo);
    }


    function formWasSubmitted(e: React.FormEvent<HTMLFormElement>) {
        e.preventDefault();
        console.log(formInfo);
        let url = `http://localhost:3221/manager/login`;
        axios.get(url, { params: { name: formInfo.name, password: formInfo.password } })
            .then(response => {
                console.log(response.data);
                let user = response.data
                if (response.data === true) {

                    alert("successful logged in");
                    Navigate('./formanager')

                    // newUser.first = user.first;
                    // newUser.last = user.last;
                    // newUser.phone = user.phone;

                    // newUser.hall = user.hall;
                    // newUser.kindevent = user.kindevent;
                    // newUser.date = user.date
                    // newUser.people = user.people


                }
            });

        // axios.get(url, { params: login.phone })
        //     .then(Response => {
        //         let users = Response.data
        //         console.log(Response);

        //         if (users.name === login.phone) {

        //             if (login.password === users.password) {
        //                 alert('login successful');

        // newUser.userName = users.userName
        // newuser.birth = users.birth
        // newuser.Email = users.Email
        // newuser.password = users.password

        // Navigate('./AfterRes')
        //         }

        //         else {
        //             alert('login faild'
        //             );
        //         }
        //     }
        //     else {
        //         alert('login faild'
        //         );
        //     }


        // })

    }





    return (

        <div className='Login' >
            <div className='title'><h1>Log In</h1></div>
            <div className='container'>
                <div className='left'></div>
                <div className='right'>
                    <div className='formBox'>
                        <form onSubmit={(e) => { formWasSubmitted(e) }}>

                            <p>Name</p>
                            <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                setSomeStr(e.target.value);
                                textWasChanged(e, "name")
                            }}
                                type="text" name="name" placeholder='name' />
                            <p>Password</p>
                            <input onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                setSomeStr(e.target.value);
                                textWasChanged(e, "password")
                            }}
                                type="Password" name='password' placeholder='•••••••' />
                            <input type="submit" value="Log In" />
                        </form>

                    </div>
                </div>
            </div>
        </div>
    )
}
