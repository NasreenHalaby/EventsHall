import axios from 'axios';
import React, { useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom';
import { newUser } from '../App';
import { Addevent } from './Addevent';
import { Allreservations } from './Allreservations';
import './Formanager.css';
import { GiClick } from "react-icons/gi";
import { BsArrow90DegDown } from "react-icons/bs";



export function ForManager() {
    const Navigate = useNavigate();

    function buttonClick() {

        Navigate('./Addevent')
    }

    function buttonClick2() {

        Navigate('./Allreservations')
    }
    // if (click.button === 2) {
    //     return <Allreservations />;
    // }
    // // }

    return (
        <div className='aroundButtons'>
            <h1> Welcome Admin</h1> <br /> <br />
            <div className='Buttonn'>
                <div className='hbutton'>
                    <h2>Click Here To Add Event <br /> <BsArrow90DegDown />  </h2>
                    <button className='buttonn1' onClick={buttonClick}> <GiClick /> ADD EVENT </button>
                </div>
                <br />
                <div className='tasters'>
                    <h2> Click To See All The Tasters <br /> <BsArrow90DegDown /></h2>
                    <button className='buttonn2' onClick={buttonClick2}>  <GiClick />  ALL TASTERS</button>
                </div>
            </div>
        </div>
    )
}
