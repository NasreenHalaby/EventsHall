import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { newUser } from '../App';
import './Allreservations.css';

export function Allreservations() {
    const [shouldReloadRse, setshouldReloadRse] = useState(true)
    let url = `http://localhost:3221/users/allreservatios`;
    const [reservation, setReservation] = useState
        ([{
            id: "",
            first: "",
            last: "",
            phone: "",
            email: "",
            hall: "",
            foodtype: "",
            date: "",
        }]);

    function EditReservation() {


    }






    // function getTasters() {
    useEffect(() => {
        let theNewUserId = ""

        axios.get(url)
            .then(response => {
                // console.log(response.data);
                setReservation(response.data);
                theNewUserId = response.data.id
            });

    }, []);



    return (
        <div className='allres'>
            <div className='titlee'><h2> All Reservations</h2></div>
            <div className='reservations'>
                <ul >
                    {reservation.map((curr, i) => {
                        return <Res key={i} {...curr}></Res>;
                    })}
                </ul>

            </div>
        </div>
    )
}
function DeleteReservation() {
    let url3 = "http://localhost:3221/users/id"
    // url3 = url3 + reservation.id;
    axios.delete(url3)
        .then(response1 => {
            console.log(response1.data);
            let msg = JSON.stringify(response1.data);
            if (msg === '"deleted user"') {
                alert(msg);
            }

        })

}

const Res = (props: {
    id: String,
    first: String,
    last: String,
    phone: String,
    email: String,
    hall: String,
    foodtype: String,
    date: String,
}) => {
    return (
        <div className='cards'>
            <li> first: {props.first} <br />
                last: {props.last}<br />
                phone: {props.phone}<br />
                email: {props.email}<br />
                hall: {props.hall}<br />
                foodtype: {props.foodtype}<br />
                date: {props.date}
                <div className='bton'>
                    <button className='butto'  >  Edit Reservation </button>
                    <button onClick={DeleteReservation} className='butto' >  Delete Reservation </button>
                </div>

            </li>


        </div>


    )
}

// function id(url3: string, id: any) {
//     throw new Error('Function not implemented.');
// }
