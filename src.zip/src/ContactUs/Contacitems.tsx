


export let contactArr = {

    "TheinnerHTML": " <h1 class='Title'>Contact Us </h1> <p class='Text'>We would love to hear from you!<br /><br /> Where We're Located:<br /> Israel, Haifa, Dalyat El- Carmel.<br /> <br /> Tel: + 972(0)3 - 7111000<br /> Fax: + 972(0)3 - 5604324 </p >"
}

