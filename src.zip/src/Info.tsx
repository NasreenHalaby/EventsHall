import React from 'react'

export function Info() {
    return (
        <div>
            
        </div>
    )
}


