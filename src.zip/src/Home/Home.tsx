import './Home.css'
import { useEffect, useState } from 'react';
import { homeArr } from './Homeitem';
import axios from 'axios';



export function Home() {
  // const url6 = "http://localhost:3221/homearr/home";
  // const [homArr, sethomArr] = useState([{ title: "", url: "" }]);
  // useEffect(() => {
  //   axios.get(url6)
  //     .then(response => {
  //       console.log(response.data);
  //       sethomArr(response.data);
  //     });
  // }, []);

  useEffect(() => {
    (document.querySelector('.cards') as HTMLElement).innerHTML = homeArr.myinnerHTML
  }, [])


  return (

    <div className='home'>

      <div className='cards'>

        {/* <div className='text'>
          
        </div> */}
      </div >
      <div className='home-text'>
        <br /> <h4> Why choose to host your event at our three amazing event venues? </h4><p>Because not only do we provide some of the most beautiful banquet halls, we also offer client service that is both friendly and professional, <br /> with excellent communication and passion to see your vision through to success.<br /><br />No matter what you have in mind for your wedding, birthday, fundraiser, or any other type of event, we will do everything we can to help it take shape <br />From the catering to the décor to the amenities, our team will work with you every step of the way to make all your hard work and planning pay off. <br />Whether you want a large, lavish event, a mid-sized party, oran intimate gathering in a chic, cozy space, we can provide the perfect venue for your preference.<br /> <br />Every event is unique, with its own story and requirements, and our team understands how to meet the needs of every specific client. <br />We love seeing our client's vision come together to create stunning events that become lifetime memories for everyone involved.<br />We understand that the events that take place in our event venues are very special, and that’s why we go the extra mile to help make everything go as smoothly and correctly as we possibly can.<br /><br /> If you’re looking for a banquet hall in Israel that offers the best of all worlds — atmosphere, cuisine, service, and reputation —  <br /> our venues is what you’ve been searching for.</p >
      </div>
      <br />
      <div className='home-halls'>
        <div className='img-sky'>
        </div>
        <div className='sky-text'>
          <h2>Sky Garden</h2>
          <p>In your special day, <br /> let us make you feel as if you're up high in the sky, with an unforgettable celebration that includes the best DJs an finest cocktails. <br />It all happens in our uniquely joyful event hall - Sky Garden.
            <br /> <a href='./Skygarden'> <br />click for more details </a>
          </p>
        </div>
      </div>

      <div className='line'></div>

      <div className='home-halls'>
        <div className='img-taj'>
        </div>
        <div className='sky-text'>
          <h2>Taj Mahal</h2>
          <p>Let us make the event of your dreams come true in Taj Mahal,with it's indoor and outdoor feels, the  marvelous  lighting <br />that resembles art,<br />and the best modern design.
            <br /> <a href='./TajMahal'> <br />click for more details </a>
          </p>
        </div>
      </div>
      <div className='line'></div>


      <div className='home-halls'>
        <div className='img-bos'>
        </div>
        <div className='sky-text'>
          <h2>El-Bostan</h2>
          <p>For an amazing opened air event, that includes an incredible garden design and a breathtaking sunset view of the glamorous <br /> Carmel mountain, El-Bostan will be your perfect choice.
            <br /> <a href='./Elbostan'> <br />click for more details </a>
          </p>
        </div>


      </div>
      <div className='line'></div>

    </div>

  );
}

// const Homearr = (props: {
//   title: string, url: string
// }) => {
//   return (

//     <li><a href={props.url}> {props.title}</a> </li>
//   )
// }













