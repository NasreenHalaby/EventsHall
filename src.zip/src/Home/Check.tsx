import React, { useState } from 'react'
import { BiWinkSmile } from 'react-icons/bi';
import { FcCalendar } from 'react-icons/fc';
import { useNavigate } from 'react-router-dom';
import { newUser } from '../App';
import { Calendarr } from '../Reservation/Calendarr';
import { Calendar2 } from './Calendar2';
import './Check.css'
import { AiOutlineSmallDash } from 'react-icons/ai'

export function Check() {
    const Navigate = useNavigate()
    function buttonClick0() {
        // return <Calendar2 />
        Navigate('./calendar2')
    }
    let [formInfo, setFormInfo] = useState({
        hall: "",

    })

    newUser.hall = formInfo.hall;


    let [someStr, setSomeStr] = useState("");

    function textWasChanged(

        e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLTextAreaElement> | React.ChangeEvent<HTMLSelectElement>,
        whichField: string) {
        // console.log("aaa" + dates);



        let newObj = {
            ...formInfo,
            ...{
                [whichField]: e.target.value
            }
        };
        setFormInfo(newObj);

    }
    return (
        <div className='check-page'>

            <div className='checkk'>
                <div className='h2'><h2>Check Available Dates<FcCalendar className='icon-calendar' />
                </h2>  <AiOutlineSmallDash className='points' /> </div>
                <div className='ch'>

                    <div className='hallevent'>
                        <label className="lbl"> Choose your event hall:
                            <select onChange={(e) => { textWasChanged(e, "hall") }}
                                name="event hall " id="select" placeholder="event hall " >
                                <option value=" "> </option>
                                <option value="Taj Mahal">Taj Mahal </option>
                                <option value="Elbostan">EL-Bostan</option>
                                <option value="Sky Garden">Sky Garden</option>
                            </select>

                        </label>
                    </div>
                    <div className='buttonn'>
                        <button className='buttonn1' onClick={buttonClick0}> Next</button>

                    </div>
                </div>
            </div>
        </div>)
}
