import React, { useEffect, useState } from 'react'
import 'antd/dist/antd.css';
import { Calendar, Badge } from 'antd';
import './Calendar2.css'
import axios from 'axios';
import { newUser } from '../App';
import moment from 'moment';
import 'moment/locale/zh-cn';
import { CalendarMode } from 'antd/lib/calendar/generateCalendar';
import { CalendarProps } from 'antd-weekly-calendar/dist/components/types';
import { BsDot } from 'react-icons/bs';
moment.locale('zh-cn');

export function Calendar2() {

    const [event, setEvent] = useState([{ id: "", date: "" }])
    useEffect(() => {
        const url = "http://localhost:3221/users/findeventbyhall"
        axios.get(url, { params: { hall: newUser.hall } })
            .then(response => {
                console.log(newUser.hall);
                let eventss = response.data;
                console.log(eventss);

                setEvent(eventss);
            })



    }, []);



    function getListData(value: any) {
        // The default locale is en-US, if you wan to use other locale, just set locale in entry file globally.


        let dateValue = value.format("yyyy-MM-DD")

        let listData1 = { type: "success" };

        for (let i = 0; i < event.length; i++) {
            if (event[i].date === dateValue) {
                listData1 = { type: 'error' }
                return listData1;

            }
            // for (let i = 0; i < event.length; i++) {
            // if (event[i].date === dateValue) {
            // // const theDate = event[i].date

            // let data = res.data;
            //         // if (data != undefined) {
            //         //     i++
            //         // }

            //         if (data === false ) {
            //             listData1 = { type: 'warning', content: 'full' }
            //             return listData1;
            //         }


            // }}
        }
        return listData1 || {};




        // switch (dateValue) {
        //     case 8:
        //         listData = [
        //             { type: 'warning', content: 'This is warning event.' },
        // { type: 'success', content: 'This is usual event.' },
        //         ];
        //         break;
        //     case 10:
        //         listData = [
        //             { type: 'warning', content: 'This is warning event.' },
        //             { type: 'success', content: 'This is usual event.' },
        //             { type: 'error', content: 'This is error event.' },
        //         ];
        //         break;
        //     case 15:
        //         listData = [
        //             { type: 'warning', content: 'This is warning event' },
        //             { type: 'success', content: 'This is very long usual event。。....' },
        //             { type: 'error', content: 'This is error event 1.' },
        //             { type: 'error', content: 'This is error event 2.' },
        //             { type: 'error', content: 'This is error event 3.' },
        //             { type: 'error', content: 'This is error event 4.' },
        //         ];
        //         break;
        //     default:
        // }
        // return listData || [];

    }

    function dateCellRender(value: any) {
        let listData = getListData(value);
        // console.log(listData.type);
        let aa: "error" | "success" | "processing" | "default" | "warning" | undefined = "success"


        switch (listData.type) {


            case ("success"):
                // console.log(aa)
                aa = "success";
                break;

            case ("error"):

                aa = "error";
                break;
        }
        if (aa === "error") {
            return (
                <ul className="eventss" >
                    {/* {listData.map(item => ( */}
                    <li>
                        <Badge status={aa} />
                    </li>

                </ul>
            );
        }
        else {
            return (
                <ul className="eventss" >
                    {/* {listData.map(item => ( */}
                    <li>
                        <Badge status={aa} />
                    </li>

                </ul>
            );
        }
    }

    function getMonthData(value: { month: () => number; }) {
        if (value.month() === 8) {
            return 1394;
        }
    }

    function monthCellRender(value: any) {
        const num = getMonthData(value);
        return num ? (
            <div className="notes-month">
                <section>{num}</section>
                <span>Backlog number</span>
            </div>
        ) : null;
    }


    // function(date: moment）
    // function onSelect(date: moment.Moment) {
    //     let dateValue1 = date.format("yyyy-MM-DD")
    //     console.log(dateValue1);
    //     newUser.date = dateValue1;
    // const url2 = "http://localhost:3221/users/justtry"


    // axios.get(url2, { params: { hall: newUser.hall, date: newUser.date } })
    // .then(res => {
    //     console.log(res);

    // })

    // }





    return (
        <div className='aroundcal'>

            <div className='calendarr'>

                <Calendar dateCellRender={dateCellRender}
                    monthCellRender={monthCellRender}
                // onSelect={onSelect}


                />
            </div>

            <div> <h2><BsDot className='point' /> Green : available</h2>

            </div>
        </div>
    )
}
