// let allUsers = require('./UsersJson').users;
// const { location } = require('express/lib/response');
const Usermodel = require('./usersReservation');
const User = Usermodel.usersres;

const Eventmodel = require('./usersReservation');
const Events = Eventmodel.events;

const tasterModel = require('./usersReservation');
const tasters = tasterModel.tasters;

const qs = require('qs')

const axios = require("axios")




//get events dates
const findEventsByDate = async (theDate) => {
    console.log(theDate);
    const x = await Events.find({ date: theDate })
    console.log(`findEventsByDate ${JSON.stringify(x)}`);
    return x;
}
exports.findEventsByDate = findEventsByDate;


const findEventsByHall = async (hall, foodtype) => {
    console.log(foodtype);
    console.log("-----------");
    console.log(hall);
    const x = await Events.find({ hall: hall, foodtype: foodtype }, { date: 1 })
    // console.log('::::::');
    console.log(x);
    return (x)
    // console.log(`findEventsByHall ${JSON.stringify(x)}`);
    // for (let i = 0; i < x.length; i++) {
    //     if (x[i].tastersArr === 3) {
    //         return false

    //     }
    // }

}
exports.findEventsByHall = findEventsByHall;

const sendSms = async (phoneNumber) => {

    let url = "https://la.cellactpro.com/unistart5.asp";
    axios({
        method: 'post',
        url: url,
        data: qs.stringify({
            XMLString:
                `<PALO>
            <HEAD>
             <FROM>ofns</FROM>
             <APP USER="ofns" PASSWORD="F4VGqr7D">LA</APP>
             <CMD>sendtextmt</CMD>
             <CONF_LIST>
              <TO TECH='post'>http://192.168.154.28/CellactCod/cod.asp</TO>
             </CONF_LIST>
            </HEAD>
            <BODY>
            <SENDER>Nasreen</SENDER>
            <CONTENT><![CDATA[Hello >>>>>>>> World>]]></CONTENT>
            <DEST_LIST>
            <TO>+972523075855</TO>
            </DEST_LIST>
            </BODY>
            <OPTIONAL>
             <MSG_ID>1123527</MSG_ID>
             <SERVICE_NAME>string</SERVICE_NAME>
            </OPTIONAL>
        </PALO>`

        }),
        headers: {
            'content-type': 'application/x-www-form-urlencoded;charset=utf-8'
        }

    })
        .then((data) => {

            console.log("this is the data from axios", data);
        })

}
exports.sendSms = sendSms;


const findByHallAndDate = async (hall) => {
    console.log(hall);
    const x = await Events.find({ hall: hall }, { date: 1 })
    console.log(`findByHallAndDate ${JSON.stringify(x)}`);
    return x;
}
exports.findByHallAndDate = findByHallAndDate;

//add event
const addNewEvent = async (event) => {
    console.log("???");
    console.log("--", JSON.stringify(event));
    const newevent = new Events(event);
    const x = await newevent.save();
    console.log(x);
    console.log(`addNewuEvent ${JSON.stringify(x)}`);
    return true;
};
exports.addNewEvent = addNewEvent;


// Update info of a user reservation by its id
const updateUserByPhone = async (userphone, resInfo) => {
    const x = await User.updateOne({ phone: userphone }, resInfo);
    if (x !== null) {
        return true;
    }
    return false;

};
exports.updateUserByPhone = updateUserByPhone;


// Get all users
const getAllUsers = async () => {
    const x = await User.find();
    console.log(`getAllUsers ${JSON.stringify(x)}`);
    return JSON.parse(JSON.stringify(x));

};
exports.getAllUsers = getAllUsers;


//check if date and place exist
const checkIfExist = async (date, hall) => {
    const users = await findUserByDate(date)
    console.log(users);
    for (let i = 0; i < users.length; i++) {
        if (users[i].hall === hall) {
            return false

        }
    }
    return true

};
exports.checkIfExist = checkIfExist;

//check if phone and password exist
const checkIfUserExist = async (phone, password) => {
    const users = await findUserByPhone(phone)

    if (users.password === password) {
        return true
    }
    //}
    return false

};
exports.checkIfUserExist = checkIfUserExist;

//------------------------------------------
// Delete a user by its id
const deleteUserById = async (theId) => {
    // console.log(thePhone);
    const x = await User.deleteOne({ id: theId });
    console.log(x);
    if (x !== null) {
        console.log(`deleteUserByID ${JSON.stringify(x)}`);
        return true;
    }

    return false;

};
exports.deleteUserById = deleteUserById;



// Add a user 
const addNewUser = async (user) => {
    console.log("???");
    console.log("--", JSON.stringify(user));
    const newuser = new User(user);
    console.log(newuser);
    const x = await newuser.save();
    console.log(`addNewuser ${JSON.stringify(x)}`);
    return x._id;
};
exports.addNewUser = addNewUser;


//adding taster to tatersArr
const AddTaster = async (hall, date, objIdOfPerson) => {

    let tempEvent = await Events.updateOne({ hall: hall, date: date }, { $push: { tastersArr: objIdOfPerson } })
    // tempEvent.tastersArr.push(objIdOfPerson)
    // tempEvent.save();
    return ("hello world")

    // router.put("/:username", async (req, res) => {
    //     await User.updateOne({ userName: req.params.username }, { $push: { trips: req.body } });
    //     res.json("the trip has been added");

    //   });


};
exports.AddTaster = AddTaster;






const FindMaxTasters = async (hall, date) => {
    const x = await Events.find({ hall: hall, date: date })
    console.log(hall);
    console.log(date);
    // console.log(x);

    for (let i = 0; i < x.length; i++) {
        if (x[i].tastersArr === 3) {
            return false

        }
    }
    // console.log(x[0]);
    // console.log(x[0].tastersArr);
    // const y = await User.find({_id:x[0].tastersArr[0]})
    // console.log(y);
    // let z=7






    // let count = 0;
    // for (let i = 0; i < x.length; i++) {
    //     count = count + x[i].people

    // }
    // if (count <= 10) {
    //     console.log(count);
    //     console.log('//');
    //     return true;
    // }

    // console.log(count);
    // console.log('///////');
    // return false;



}
exports.FindMaxTasters = FindMaxTasters;



const findUserByDate = async (theDate) => {
    console.log(theDate);
    const x = await User.find({ date: theDate })
    console.log(`findUserByDate ${JSON.stringify(x)}`);
    return x;
}
exports.findUserByDate = findUserByDate;


const findUserByPlace = async (thePlace) => {
    const x = await User.findOne({ eventHall: thePlace })
    console.log(`findUserByPlace ${JSON.stringify(x)}`);
    return x;
}
exports.findUserByPlace = findUserByPlace;

const findUserByPhone = async (thePhone) => {
    const x = await User.findOne({ phone: thePhone })
    console.log(`findUserByPhone ${JSON.stringify(x)}`);
    return x;
}
exports.findUserByPhone = findUserByPhone;











//==========================================================================
//add users
// const addUser = (user) => {
//     console.log(user);
//     for (let i = 0; i < allUsers.length; i++) {
//         if (allUsers[i].eventHall === user.hall && allUsers[i].date == user.date) {
//             return false;
//         }
//     }
//     allUsers.push(user);
//     return true;

// }

// exports.addUser = addUser;

///========================================================================
//delete user by first name
// const deleteUserByName = (username) => {
//     for (let i = 0; i < allUsers.length; i++) {
//         console.log(allUsers[i].first);
//         if (allUsers[i].first === username) {
//             allUsers.splice(i, 1);
//             return true;
//         }
//     }
//     return false;
// }
// exports.deleteUserByName = deleteUserByName;



// }
//--------------------------------------

// Update info of a user by its phone number
