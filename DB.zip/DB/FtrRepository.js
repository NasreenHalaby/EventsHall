let Footer = require('./FooterJson').footerArr;

//Get All footer
const GetAllFooter = () => {
    return Footer;
};
exports.GetAllFooter = GetAllFooter;