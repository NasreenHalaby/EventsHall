exports.footerArr = [
    {
        title: "Contact Us",
        url: "contactUs"
    },
    {
        title: "Help Center",
        url: "help Center"
    },
    {
        title: "About Us",
        url: "aboutUs"
    },
    {
        title: "Media Center",
        url: "media Center"
    },
    {
        title: "How It Works",
        url: "howitworks"
    },

    // {
    //     title: "Personal Reservation",
    //     url: "afterres"
    // },

    {
        title: "For Manager",
        url: "/manager"
    }
];