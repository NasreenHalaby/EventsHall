exports.navArr = [

    {
        "title": "HOME",
        url: "/home",
    },
    {
        title: "TAJ MAHAL",
        url: "/tajmahal"
    },
    {
        title: "EL-BOSTAN",
        url: "/elbostan"
    },
    {
        title: "SKY GARDEN",
        url: "/skygarden"
    },
    {
        title: "MENU",
        url: "/menu"
    },
    {
        title: "COME & TASTE",
        url: "/reservation"
    },
    {
        title: " CHECK AVAILABILITY",
        url: "/check"
    },

]