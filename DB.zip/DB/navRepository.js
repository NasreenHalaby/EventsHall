let Navbar = require('./NavJason').navArr;

//Get All nav
const GetAllNav = () => {
    return Navbar;
};
exports.GetAllNav = GetAllNav;