
const mongoose = require('mongoose');
var url = "mongodb+srv://Nasreen:Nasreen123@cluster0.96xdk.mongodb.net/users?retryWrites=true&w=majority";
mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Connected successfully to MongoDB!'))
    .catch(err => console.error('Something went wrong', err));

const SgImages = new mongoose.Schema({
    img: String,

})


const ManagerPage = new mongoose.Schema({
    name: String,
    password: String,

})

const Events = new mongoose.Schema({
    hall: String,
    date: String,
    hour: String,
    foodtype: String,
    peoplenumber: String,

    tastersArr: {
        type: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: 'reservationSchema'
        }],

        validate: [arrayLimit, '{PATH} exceeds the limit of 3']
    },


})

function arrayLimit(val) {
    return val.length <= 3;
}

// const tasterModel = new mongoose.Schema({
//     hall: String,
//     date: String,
//     people: String,

// })





//  Defining schema for a users
const reservationSchema = new mongoose.Schema({
    first: String,
    last: String,
    phone: String,
    email: String,
    hall: String,
    foodtype: String,
    date: String,
    // isOpenForTasting: { type: Boolean, default: false },
    // tastersArray: {

    // }
});






module.exports.usersres = mongoose.model('usersres', reservationSchema);
// module.exports.tasters = mongoose.model('tasters', tasterModel);
module.exports.managers = mongoose.model('managers', ManagerPage);
module.exports.events = mongoose.model('events', Events);
// module.exports.maxtasters = mongoose.model('maxtasters', maxTasters);
module.exports.images = mongoose.model('images', SgImages);



