const Managermodel = require('./usersReservation');
const manager = Managermodel.managers;

const checkIfManagerExist = async (name, password) => {
    const users = await findManagerByName(name)
    if (users.password === password) {
        return true
    }
    return false

};
exports.checkIfManagerExist = checkIfManagerExist;



const findManagerByName = async (name) => {
    console.log(name);
    const x = await manager.findOne({ name: name })
    console.log(x);
    console.log(`findManagerByName ${JSON.stringify(x)}`);
    return x;
}
exports.findManagerByName = findManagerByName;