const Imgesmodel = require('./usersReservation');
const Img = Imgesmodel.images;


const getAllImages = async () => {
    const x = await Img.find();
    console.log(`getAllImages ${JSON.stringify(x)}`);
    return JSON.parse(JSON.stringify(x));
};
exports.getAllImages = getAllImages;